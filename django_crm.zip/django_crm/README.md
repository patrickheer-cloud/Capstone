# Django CRM Project

## Project Location
C:\Users\Patrick\Desktop\django_crm

## Quick Start Commands

### Start Working
```cmd
cd C:\Users\Patrick\Desktop\django_crm
venv\Scripts\activate
python manage.py runserver
```

### Access Application
- Main App: http://127.0.0.1:8000/
- Admin Panel: http://127.0.0.1:8000/admin/

### Useful Commands
```cmd
# Create new migration after model changes
python manage.py makemigrations

# Apply migrations
python manage.py migrate

# Create new superuser
python manage.py createsuperuser

# Open Django shell
python manage.py shell
```

## Project Structure
```
django_crm/
├── venv/                          # Virtual environment
├── crm_project/                   # Main project settings
│   ├── settings.py
│   └── urls.py
├── crm/                          # CRM app
│   ├── models.py                 # Database models
│   ├── views.py                  # View functions
│   ├── urls.py                   # URL routing
│   ├── admin.py                  # Admin configuration
│   └── templates/crm/            # HTML templates
├── db.sqlite3                    # Database file
└── manage.py                     # Django management
```

## Features
- Contact Management
- Activity Logging (Calls, Emails, Meetings)
- Task & Reminder System
- Sales Logging
- Sales History Charts

## Claude.ai Conversation
Link to conversation: [Paste your conversation link here]

## Future Feature Ideas
- [ ] Email integration
- [ ] Calendar view for tasks
- [ ] Contact import/export
- [ ] Search functionality
- [ ] Custom fields
- [ ] Reports and analytics